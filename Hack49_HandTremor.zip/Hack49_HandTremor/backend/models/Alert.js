const mongoose = require('mongoose');

const AlertSchema = new mongoose.Schema({
  patientId: String,
  message: String,
  timestamp: Date
});

module.exports = mongoose.model('Alert', AlertSchema);
