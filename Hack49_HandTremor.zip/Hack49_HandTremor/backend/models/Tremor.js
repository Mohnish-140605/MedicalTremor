const mongoose = require('mongoose');

const TremorSchema = new mongoose.Schema({
  patientId: String,
  frequency: Number,
  amplitude: String,
  timestamp: Date,
  location: String
});

module.exports = mongoose.model('Tremor', TremorSchema);
