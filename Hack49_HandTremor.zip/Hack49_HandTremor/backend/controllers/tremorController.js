const Tremor = require('../models/Tremor');
const fs = require('fs');
const path = require('path');

// Load tremorData.json
const tremorDataPath = path.join(__dirname, '../data/tremorData.json');

// Get all tremors
exports.getTremors = async (req, res) => {
  try {
    let tremors = await Tremor.find();

    if (tremors.length === 0) {
      const tremorData = JSON.parse(fs.readFileSync(tremorDataPath, 'utf-8'));
      tremors = await Tremor.insertMany(tremorData);
    }

    res.json(tremors);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Add new tremor data
exports.addTremor = async (req, res) => {
  try {
    const { patientId, frequency, amplitude, timestamp, location } = req.body;
    const tremor = new Tremor({ patientId, frequency, amplitude, timestamp, location });
    await tremor.save();

    res.status(201).json(tremor);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
