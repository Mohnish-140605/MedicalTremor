const express = require('express');
const { getTremors, addTremor } = require('../controllers/tremorController');

const router = express.Router();

router.get('/', getTremors);
router.post('/', addTremor);

module.exports = router;
