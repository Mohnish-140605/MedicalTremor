MedicalTremor/
│
├── backend/
│   ├── models/
│   │   ├── Tremor.js
│   │   └── Alert.js
│   ├── controllers/
│   │   ├── tremorController.js
│   │   └── alertController.js
│   ├── routes/
│   │   ├── tremorRoutes.js
│   │   └── alertRoutes.js
│   ├── config/
│   │   └── db.js
│   ├── .env
│   ├── package.json
│   └── server.js
│
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   │   └── PatientDashboard.js
│   │   ├── App.js
│   │   ├── index.js
│   │   └── App.css
│   ├── .env
│   ├── package.json
│   └── README.md
│
└── README.md
