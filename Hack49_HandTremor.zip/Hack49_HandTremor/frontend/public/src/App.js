import React from 'react';
import PatientDashboard from './components/PatientDashboard'; 

const App = () => {
  return (
    <div className="App">
      <PatientDashboard />
    </div>
  );
};

export default App;
