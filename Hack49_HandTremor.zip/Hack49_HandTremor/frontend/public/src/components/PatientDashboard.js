import React, { useEffect, useState } from 'react';
import axios from 'axios';

const PatientDashboard = () => {
  const [tremorData, setTremorData] = useState([]);
  const [alerts, setAlerts] = useState([]);

  const fetchTremors = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/tremors`);
      setTremorData(response.data);
    } catch (error) {
      console.error("Error fetching tremor data:", error);
    }
  };

  const fetchAlerts = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/alerts`);
      setAlerts(response.data);
    } catch (error) {
      console.error("Error fetching alerts:", error);
    }
  };

  useEffect(() => {
    fetchTremors();
    fetchAlerts();
  }, []);

  return (
    <div>
      <h1>Tremor Monitoring System</h1>

      <section>
        <h2>Tremor Data</h2>
        {tremorData.length > 0 ? (
          <ul>
            {tremorData.map((tremor, index) => (
              <li key={index}>
                <p><strong>ID:</strong> {tremor.patientId}</p>
                <p><strong>Timestamp:</strong> {tremor.timestamp}</p>
                <p><strong>Frequency:</strong> {tremor.frequency}</p>
                <p><strong>Amplitude:</strong> {tremor.amplitude}</p>
                <p><strong>Location:</strong> {tremor.location}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p>No tremor data available.</p>
        )}
      </section>

      <section>
        <h2>Alerts</h2>
        {alerts.length > 0 ? (
          <ul>
            {alerts.map((alert, index) => (
              <li key={index}>
                <p><strong>ID:</strong> {alert.patientId}</p>
                <p><strong>Message:</strong> {alert.message}</p>
                <p><strong>Timestamp:</strong> {alert.timestamp}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p>No alerts available.</p>
        )}
      </section>
    </div>
  );
};

export default PatientDashboard;
